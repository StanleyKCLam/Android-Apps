package androidhive.info.materialdesign.activity;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.os.StrictMode;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;

import androidhive.info.materialdesign.R;


public class MessagesFragment extends Fragment {


    public MessagesFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (android.os.Build.VERSION.SDK_INT > 9) {
            StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
            StrictMode.setThreadPolicy(policy);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        final View rootView = inflater.inflate(R.layout.fragment_messages, container, false);

        Button button1;
        button1 = (Button) rootView.findViewById(R.id.button1);
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                HttpURLConnection urlConnection = null;
                final EditText et = (EditText) rootView.findViewById(R.id.editText1);
                String source = et.getText().toString();

                try {
                    URL url = new URL(
                            "http://ajax.googleapis.com/ajax/services/language/translate?v=1.0&q="
                                    + source + "&langpair=en|zh-TW");

                    urlConnection = (HttpURLConnection) url.openConnection();

                    InputStreamReader in = new InputStreamReader(urlConnection.getInputStream());
                    BufferedReader br = new BufferedReader(in);
                    String json_result = br.readLine();

                    final TextView tv = (TextView) rootView.findViewById(R.id.textView1);
                    JSONObject jsonObject = new JSONObject(json_result);
                    if (json_result != null) {
                        String answer = jsonObject.getJSONObject("responseData").getString("translatedText");
                        tv.setText(answer);
                    }

                    br.close();
                    in.close();
                } catch (Exception E) {
                    Log.e("and", "Err:" + E);
                } finally {
                    urlConnection.disconnect();
                }

            }
        });
        // Inflate the layout for this fragment
        return rootView;
    }


}












