package androidhive.info.materialdesign.activity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import androidhive.info.materialdesign.R;


public class LanguageFragment extends Fragment {


    public LanguageFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_language, container, false);

        // build dialog box to display when user clicks the flag
        AlertDialog.Builder builder = new AlertDialog.Builder(rootView.getContext());
        builder.setTitle(R.string.dialog_title)
                .setMessage(R.string.dialog_text)
                .setCancelable(false)
                .setPositiveButton("Done",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                dialog.dismiss();
                            }
                        });
        final AlertDialog alert = builder.create();

        // assign flag.png to the button, loading correct flag image for current locale
        Button b = (Button) rootView.findViewById(R.id.flag_button);
        b.setBackground(this.getResources().getDrawable(R.drawable.flag));

        // set click listener on the flag to show the dialog box
        b.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                alert.show();
            }
        });

        // Inflate the layout for this fragment
        return rootView;
    }
}
